import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Lab1Component } from './lab1/lab1.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { Lab2Component } from './lab2/lab2.component';

@NgModule({
  declarations: [
    AppComponent,
    Lab1Component,
    Lab2Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
