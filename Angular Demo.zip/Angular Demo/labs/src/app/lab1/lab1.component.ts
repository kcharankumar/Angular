import { Component, OnInit } from '@angular/core';
import {user} from '../../user';

@Component({
  selector: 'app-lab1',
  templateUrl: './lab1.component.html',
  styleUrls: ['./lab1.component.css']
})
export class Lab1Component implements OnInit {

  //userForm = new user(1,'test',1000,'IT');
  //userForm = new user(1);
  id:number;
  name : string;
  finalString : string;
  constructor() { }

  ngOnInit(): void {
  }

  onSubmit()
  {
    this.finalString = ""+this.id + "," + this.name;
    

    alert ("User id "+this.finalString); 
  }

}
