import { Component, OnInit } from '@angular/core';
import {user } from "../../user";
import {Login} from "../../Login"

@Component({
  selector: 'app-lab2',
  templateUrl: './lab2.component.html',
  styleUrls: ['./lab2.component.css']
})
export class Lab2Component implements OnInit {

    userForm = new user(101, "Rajesh", 20000, "IT");
    userFormList : user[]=[] ;
    editFormRecord = new user(0, "", 0, "");
    displayLoginForm=true;
    displayRegisterForm=false;




    loginObject=new Login(0, "");
    LoginValidation()
    {
      alert (this.loginObject.id + " " + this.loginObject.pwd);
    }

    Register()
    {
      this.displayLoginForm=false;
      this.displayRegisterForm=true;
    }

    RegisterLoginDetails()
    {
      this.displayLoginForm=true;
      this.displayRegisterForm=false;
    }

    userPipeList : user[]=[new user (101, "Rajesh", 20000, "IT"),
                           new user (102, "Ravindra", 20000, "IT"),  
                           new user (103, "Pinto", 20000, "IT"),
                           new user (104, "Savita", 20000, "IT"),
                           new user (105, "Mrugalaya", 20000, "IT"),
                           new user (106, "Kalavari", 20000, "IT")
                          ]
  constructor() { }

  ngOnInit(): void {
  }

  OnSubmit()
  {
    //alert  (this.userForm.name);
    this.userFormList.push(new user(this.userForm.id, this.userForm.name, this.userForm.salary, this.userForm.department));
 
    console.log (this.userFormList);
  }

  onUpdate(editFormRecord:user)
  {
    this.editFormRecord = editFormRecord;
  }

  onDelete(userFormRecord:user)
  {
    //alert (userFormRecord.name);
    //this.userFormList.pop(userFormRecord);
    alert (userFormRecord.name);
    //this.userFormList = this.userFormList.filter(user => user.name != userFormRecord.name);
    this.userFormList = this.userFormList.filter(function (user)
    {        
         return user.name != userFormRecord.name;

    });
  }

  updateEmployee()
  {
    //alert (this.editFormRecord.name);
  }
}
