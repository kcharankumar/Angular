class SmartPhone
{
  mobileType : string;
  
  printMobileDetails ()
  {
    super.printMobileDetails();
	console.log ("Type of phone is "+mobileType);
	}
	
}
