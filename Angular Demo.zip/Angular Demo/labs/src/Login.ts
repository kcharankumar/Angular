export class Login
{
    id:number;
    pwd:String;

    constructor (id:number, pwd:String)
    {
        this.id = id;
        this.pwd = pwd;
    }
}