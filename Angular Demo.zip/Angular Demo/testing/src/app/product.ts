export class Product
{
    productId:number;
    productName:string;
    productCost:number;
}