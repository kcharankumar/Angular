  import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  constructor() { }

  collegeName:string = "PSIT";
  @Output() valueChange = new EventEmitter();

  inputOutput:boolean  = true;

  ngOnInit(): void {
  }

   @Input() namesList:string[];

   SendData()
   {
     alert ("In SendData()...");
     this.valueChange.emit (this.collegeName);
    }

}
