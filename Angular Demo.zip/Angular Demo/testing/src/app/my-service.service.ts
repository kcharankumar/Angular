import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {

  constructor() { }

  insertData()
  {
    alert ("Performing insert operation");
  }

  updateData()
  {
    alert ("Performing edit operation...");

  }

  deleteData()
  {
    alert ("Performing delete operation...");
  }

  displayData()
  {
    alert ("Performing show opearation..");
  }

}
