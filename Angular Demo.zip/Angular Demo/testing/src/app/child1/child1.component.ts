import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.css']
})
export class Child1Component implements OnInit {

//@Input() namesList :string[];

@Output() outputObj = new EventEmitter(); 
data:string = "Angular learning...";

  constructor() { }

  ngOnInit(): void {
  }

  sendData()
  {
     
    this.outputObj.emit (this.data);
  }

}
