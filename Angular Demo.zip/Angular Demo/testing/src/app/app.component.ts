import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule, FormBuilder,FormGroup, Validators } from '@angular/forms';
import {Product_info} from './Product_info';
import {ReverseStr} from './reverse-str.pipe'
import {Sort} from '@angular/material/sort'
import { stringify } from 'querystring';
import {EmployeeInfo} from './EmployeeInfo' 
import {DBServiceService} from './dbservice.service';
 
import { of } from 'rxjs/internal/observable/of';
import {map} from 'rxjs/operators';
import { ajax } from 'rxjs/ajax';
import {Book} from  './Books';
import {HttpClient, HttpClientModule} from '@angular/common/http'
import {user} from './user';
import { EmployeeService } from './employee.service';
import {Observable} from 'rxjs';
import { GlobalFile } from './GlobalFile';
  

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

 
export class AppComponent   {
  title = 'testing';
  idForRouting:number=103;

 booksList:any=[];
 book:Book;
 errorMsg:string;


 userForm = new user(101, "Rajesh", 20000, "IT");
   
   
    displayForm:boolean = false;
    
   



    userFormList : user[]=[] ;
    id:number;
    name:string;
    sal:number;
    department:string;


  
   

 constructor(private employeeService:EmployeeService )
 {

 }

 isValidUserData:any;
 
 
 i:number;
 dataString:string;
 empObj : EmployeeInfo;
 empList :  EmployeeInfo[];  
 gender:String;
 OnSubmit()
  {
    //alert  (this.gender);

if (this.gender == "male")
    alert ("Male selected");
     
    this.userFormList.push(new user(this.userForm.id, this.userForm.name, this.userForm.salary, this.userForm.department));
 
     this.employeeService.isValidUser().subscribe (
      data => { 
         

          /* 
         *******************************************************
         *                                                     *
         ******** When Observer returns a String...  ***********
         *                                                     *
         *******************************************************
         */
        //For string data.
           this.dataString = data;
         alert (this.dataString);
         console.log (this.dataString);
       
      /* 
         *******************************************************
         *                                                     *
         ******** When Observer returns an object... ***********
         *                                                     *
         *******************************************************
*/
/*
      this.empObj = data;
       this.dataString = "Employe id : " + this.empObj.id + "   Name : "+this.empObj.name + "   Dept : " + this.empObj.dept;
      
      alert (this.dataString);
      
      console.log (this.dataString);
  */     

         /* 
         *******************************************************
         *                                                     *
         ******* When the Spring REST returns a list ***********
         *                                                     *
         *******************************************************
*/ 
     
    /*
      this.empList = data;

    for (this.i=0; this.i < this.empList.length; ++this.i)
    {
      this.dataString = "Employe id : " + this.empList[this.i].id + "   Name : "+this.empList[this.i].name + "   Dept : " + this.empList[this.i].dept;
      alert (this.dataString);
    }
 */
 
     },
     (error) => {this.errorMsg = error; alert (this.errorMsg); alert (GlobalFile.userID);} 
     ); 
    console.log (this.userFormList);
  }



  onDelete(userFormRecord:user)
  {
    //alert (userFormRecord.name);
    //this.userFormList.pop(userFormRecord);
    alert (userFormRecord.name);
    //this.userFormList = this.userFormList.filter(user => user.name != userFormRecord.name);
    this.userFormList = this.userFormList.filter(function (user)
    {        
         return user.name != userFormRecord.name;

    });
  }

  //When the user clicks on Update in the table..
  onUpdate(editFormRecord:user)
  {
    this.id=editFormRecord.id;
    this.name=editFormRecord.name;
    this.sal=editFormRecord.salary;
    this.department=editFormRecord.department; 
  }

 //When the user clicks on Update Changes in the second form.
  updateRecord()
  {
     for ( let x in this.userFormList)
     {  
       //Replace the data in the table.
       
       if (this.userFormList[x].id ==  this.id)
         {
          this.userFormList[x].name = this.name;
          this.userFormList[x].salary = this.sal;
          this.userFormList[x].department = this.department;
         }

     }
  }

  getRadioData(userFormRecord:user)
  {
    alert (userFormRecord.name);
  }

 ngOnInit()
 {
    /*
   this.httpClient.get ("assets/data/books.json").
   subscribe(data =>
     {        
       console.log (data);
       this.booksList=data;
     },
    (error) =>
    {
       this.errorMsg = error.message;
       alert (this.errorMsg);

    }
    );
    
    */
 }




  stringDataForPipe:string = "This is to test reverse string pipe";
   

 
 
 

  pipedDataString:string = "This is summer and winter";
   
  namesArray = ['Rajesh', 'Ravin', 'Rap']; 

  productList : Product_info[] = [
    { productId : 101, productName : 'Samsung TV', productCost : 25000},
    { productId : 102, productName : 'MI MObile', productCost : 25000},
    { productId : 103, productName : 'LG Washing machine..', productCost : 25000}
   
  ]
     
  name1:string;
  data:number = 1234;

 sortedProduct : Product_info[];

 displayData()
 {
  alert ("Inside displayData()..."); 

  /*
  this.myDBService.insert();
  this.myDBService.update();
  this.myDBService.delete();
  this.myDBService.displayAll();
 */
 }
 
 
 sortProduct(sort: Sort)
 {  
    
  const data = this.productList.slice();

   if (!sort.active || sort.direction == '')
   {
     this.sortedProduct = this.productList;
     return;
   }

   this.sortedProduct = this.productList.sort((a,b) => {
    const isAsc = sort.direction == 'asc';

    switch(sort.active)
    {
      case 'ID' : return this.compare (a.productId, b.productId, isAsc); break;
      case 'name' : return this.compare (a.productName, b.productName, isAsc); break;
      case 'cost' : return this.compare (a.productCost, b.productCost, isAsc); break;
    }


   });
  }
  compare (a:number | string, b:number|string, isAsc:boolean)
   {
     return (a < b?-1:1) * (isAsc?1 : -1)
   }


   openURL()
   {
    // window.open("http://www.google.com", "_self");

      alert("For map()...test");
      const nums = of(1, 2, 3);
      const squareValues =   map((val: number) => val * val);
      const squaredNums = squareValues(nums);
      squaredNums.subscribe(x => alert(x));  
   }

  }

     
