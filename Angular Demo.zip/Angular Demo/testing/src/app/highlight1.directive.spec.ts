import { Highlight1Directive } from './highlight1.directive';

describe('Highlight1Directive', () => {
  it('should create an instance', () => {
    const directive = new Highlight1Directive();
    expect(directive).toBeTruthy();
  });
});
