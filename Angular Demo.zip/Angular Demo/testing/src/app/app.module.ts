import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { ChildComponent } from './child/child.component';
import { HighlightDirective } from './highlight.directive';
import { Child1Component } from './child1/child1.component';
import {ReverseStr} from './reverse-str.pipe'; 
import {MatSortModule} from '@angular/material/sort';
import { Highlight1Directive } from './highlight1.directive'; 
import {MyServiceService} from './my-service.service';
import {reverseString} from './reverseString.pipe';
import { DBServiceService } from './dbservice.service';
import { ProductListComponent } from './product-list/product-list.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import {Routes, RouterModule} from '@angular/router';
import {HttpClientModule} from '@angular/common/http' 
 
const routes : Routes = [
  {path: 'ProductListAll', component:ProductListComponent},  
  {path: 'ProductList/:id', component:ProductListComponent},  
  {path: 'ContactUS', component:ContactUsComponent}  
]; 
@NgModule({
  declarations: [
    AppComponent,
    ChildComponent,
    HighlightDirective,
    Child1Component,
    ReverseStr,
    Highlight1Directive,
    reverseString,
    ProductListComponent,
    ContactUsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatSortModule, 
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [DBServiceService], 
  bootstrap: [AppComponent]
})
export class AppModule { }
