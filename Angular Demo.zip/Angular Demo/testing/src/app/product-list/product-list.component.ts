import { Component, OnInit } from '@angular/core';
import {Product} from '../product';
import { ActivatedRoute } from '@angular/router'; 

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  
  productList:Product [] = 
       [{productId:101, productName:'Samsung TV', productCost:25000},
        {productId:102, productName:'LG TV', productCost:35000},
        {productId:103, productName:'Sony TV', productCost:45000}
]
  id:number;
   
  constructor(private route:ActivatedRoute) {
      route.params.subscribe(params =>{this.id=params['id'];}); 

      //ProductListAll  --> value of id will be undefined..
      //Product with ID  --> 102

      if (this.id != undefined)   
      {
        let id = this.id;
        this.productList = this.productList.filter(function (user)
        {     
             return user.productId == id;
    
        });
      }
   }
 
  ngOnInit(): void {
  }

  getSortOrder (prop)
  {
    return function (a,b)
    {
       
       if (a[prop] > b[prop])
        return 1;
       else if (a[prop] < b[prop])
        return -1;

        return 0;
    }
    
  }

  idSort()
  {
    this.productList.sort (this.getSortOrder("productId"));
  }
  
    nameSort()
    {
       
      this.productList.sort (this.getSortOrder("productName"));
    }

    costSort()
    {
      
      this.productList.sort (this.getSortOrder("productCost"));
    }
  
 
    onCreate()
    {
      alert ("Create operation perform here...");
    }
    onEdit()
    {
      alert ("Edit operation perform here...");
    }
    onDelete()
    {
      alert ("Delete operation perform here...");
    }
    onDisplay()
    {
      alert ("Display operation perform here...");
    }




  
}
