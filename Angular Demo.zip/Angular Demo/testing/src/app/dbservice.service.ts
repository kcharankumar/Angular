import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DBServiceService {

  constructor() { }

   insert ()
   {
     alert ("Record INSERTED...");      
   }

   update ()
   {
     alert ("updated the record successfully...");     
   }

   delete ()
   {
     alert ("deleted the record successfully...");     
   }
   displayAll ()
   {
     alert ("Displaying  the record successfully...");     
   }

}
