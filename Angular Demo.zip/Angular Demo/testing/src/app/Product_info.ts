export class Product_info
{
  productId:number;
  productName:string;
  productCost:number;
}