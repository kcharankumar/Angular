import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs';
import { EmployeeInfo } from './EmployeeInfo';
import {GlobalFile} from './GlobalFile';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private baseURL = "http://localhost:8080/employee";
  private headers = new HttpHeaders ({'Content-type':'application/json'});

  myURL:string;
  dataInEmployeeService:string;
  error:string;
  constructor(private http:HttpClient) { }

  isValidUser():Observable<any>
  {
    GlobalFile.userID = "Rajesh123";

   
    //For text and boolean data.. 
    
    this.myURL  = this.baseURL + "/isValid?UserID=Charan&Password=admin"; 
     return this.http.get(this.myURL,{responseType:'text'});
    
 


     
             
       //   This portion is to send the object and to receive the object..

/*
     let employeeObj  = new EmployeeInfo(25023, "Jahnavi", "IT");
 
     this.baseURL = this.baseURL + "/getEmployee";
     return this.http.post (this.baseURL,employeeObj );
      */



     //   For getting the list from Spring REST.
     /*
     this.myURL  = this.baseURL + "/isValid?UserID=Charan&Password=admin"; 
     return this.http.get(this.myURL);
     */
  }
}
