export class GlobalFile
{
    public static  userID :String = "Rajesh";

}