package SringBootDemo.SpringBootDemo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


public class InvalidProductIDException extends Exception{
	
	public InvalidProductIDException(String str)
	{
	   super (str);
	}
 
}
