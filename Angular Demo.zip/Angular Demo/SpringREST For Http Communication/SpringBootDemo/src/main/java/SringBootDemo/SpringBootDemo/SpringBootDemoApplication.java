package SringBootDemo.SpringBootDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*
 * 

1. Start with spring.start.io.
2. Select mvc web and rest..
3. Add controller in the same directory.
4. Add @RestController and add RequestMapping ("/") return some string...
5. Run the file and you will have the server run and start the browser with the URL http://localhost:8080

 */

/* For controller exeption handling...
 * 
 *   1. Create a custom exception named InvalidProductException.
 *   2. In the controller, if the produtId is valid throw the InvalidProductException with the appropriate message.
 *   3. At the end handle it through @Exception Handler. 
 * 
 * 
 */
/*
 * 
 *   For the global exception.  Centralized place to reponse to all the exceptions in the application.
 *   1. Create another class named GlobalException and handle both the exceptions in that.
 *   2. In the controller, throw the right exceptions.
 *   3. Test for both the exceptions with the values...
 *       
 *       http://localhost:8080/isValid?ProductId=0&name= --> This will throw InvalidProductIDException.
 *       http://localhost:8080/isValid?ProductId=10&name= --> This will throw InvalidProductNameException.
 *       http://localhost:8080/isValid?ProductId=10&name=SamsungTV --> This is the valid product Id and name.
 * 
 * 
 */


@SpringBootApplication
public class SpringBootDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemoApplication.class, args);
	}

}
