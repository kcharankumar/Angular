package SringBootDemo.SpringBootDemo.com.sunsoft.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import SringBootDemo.SpringBootDemo.Entity.Employee;
import SringBootDemo.SpringBootDemo.exception.InvalidProductIDException;
import SringBootDemo.SpringBootDemo.exception.InvalidProductNameException;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping ("/employee")
public class EmployeeController {
	
	@PostMapping (path="/getEmployee")
	public Employee getEmployeeData (@RequestBody Employee empObj)
	{
		System.out.println("Data received from Angular is "+empObj);
		
		empObj.setName("Charan");
		
		return empObj;
	}
	
	
	
	@GetMapping (path="/isValid", produces=MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<String> index(@RequestParam ("UserID") String UserID,
			@RequestParam("Password") String Password) throws InvalidProductIDException, InvalidProductNameException
	{		
		//ResponseEntity is the object of REST where you can send the text message to the sender and also the status
		// of HTTP.
		
	 
		System.out.println("In the EmployeeController...Data received is  UserID: "+UserID + " Password : "+Password);
	 		
		String strReturnString = new String("Valid User"); 
		boolean bRetString= true;
		
	
		if ((!UserID.equalsIgnoreCase("Charan")) || (!Password.equals("admin")))
		{
				strReturnString = "Invalid user";
				bRetString = false;
		}
	 	
	//	return strReturnString;
	    return new ResponseEntity<> (strReturnString, HttpStatus.OK);
		
 			 
		
		
		/*if (ProductId <= 0)
			 throw new InvalidProductIDException ("EXCEPTION: Invalid product");
		 else
			  strValidProduct = "Valid Product";
		 
		 if (name.equals(""))
			 throw new InvalidProductNameException ("Invalid Product Name");*/
		
		
		

	 
		 //This portion is to return a list... 
		/*
		 
		 Employee empObj1 = new Employee (106 , "Juliet", "IT" ) ; 
		 Employee empObj2 = new Employee (10246, "Prachi", "IT" ) ;
		 Employee empObj3 = new Employee (103,   "Prem", "IT" ) ;
		
		 HashMap <Integer,Employee> empHM = new HashMap <Integer,Employee>();
		 empHM.put(empObj1.getId(), empObj1);
		 empHM.put(empObj2.getId(), empObj2);
		 empHM.put(empObj3.getId(), empObj3);		 
		 List<Employee> empList= new ArrayList(empHM.values());
		 
		  return empList;
		*/ 
		  
		 // http://localhost:8080/employee/isValid?UserID=Rajesh&Password=admin
		
		// return empObj1;
		
		
		
	}	
	
	/* Test local exception handling with 
	 * 
	 * http://localhost:8080/isValid?ProductId=0&name=SamsungTV --> This will give InvalidProductException.
	 */
/*	@ExceptionHandler (InvalidProductIDException.class)
	public ResponseEntity<String> handleException (Exception ex)
	{
		return  new ResponseEntity<> (ex.getMessage(), HttpStatus.NOT_FOUND); 
	}
	 */
}
