package SringBootDemo.SpringBootDemo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
	 
	@ExceptionHandler ({InvalidProductIDException.class, InvalidProductNameException.class})
    public ResponseEntity<String> handleExceptions (Exception ex)
    {
    	if (ex instanceof InvalidProductIDException )
    	{
    		HttpStatus status = HttpStatus.NOT_FOUND;
    		return new ResponseEntity ("EXCEPTION : Invalid Product ID",status );
    	}
    	else if (ex instanceof InvalidProductNameException )
    	{
    		HttpStatus status = HttpStatus.NOT_FOUND;
    		return new ResponseEntity ("EXCEPTION: Invalid Product name",status );
    	}
    	else 
    	   return null;
    	
    }
 
}
