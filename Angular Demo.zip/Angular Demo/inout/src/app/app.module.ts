import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { ChildComponent } from './child/child.component';
import {ReverseStr} from './reverse_string';
import {MyServiceService} from './my-service.service';
import { HighlightDirective } from './highlight.directive';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import { FormCompComponent } from './form-comp/form-comp.component';
import { ReactiveFormsModuleComponent } from './reactive-forms-module/reactive-forms-module.component';
import {RouterModule, Routes} from '@angular/router';
import { ListComponent } from './list/list.component';
import { ContactComponent } from './contact/contact.component';
import { ObservableComponent } from './observable/observable.component';
import {HttpClientModule} from '@angular/common/http';
import {HttpModule} from '@angular/http';
import { InsuranceComponent } from './insurance/insurance.component';

const routes : Routes = [
  {path: 'ProductList/:id', component:ListComponent},
  {path: 'ContactUS', component:ContactComponent},
  {path: 'InsuranceDetails', component:InsuranceComponent}

];

@NgModule({
  declarations: [
    AppComponent,    
    ChildComponent,
    ReverseStr,
    HighlightDirective,
    FormCompComponent,
    ReactiveFormsModuleComponent,
    ListComponent,
    ContactComponent,
    ObservableComponent,
    InsuranceComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot (routes)
  ],
  providers: [MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
