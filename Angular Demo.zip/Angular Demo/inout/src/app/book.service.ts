import { Injectable } from '@angular/core';
import {Http, Response} from '@angular/http'; 
import {Observable} from 'rxjs';
//import 'rxjs/Rx';
import {map} from 'rxjs/operators';
import {catchError} from 'rxjs/operators';
 
 
import {Book} from './book';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  url = "http://localhost:4200/assets/data/books.json"; 
   body :any;
 
  constructor(private http : Http) { }
    getBooksWithObservable(): Observable<Book[]> 
    {
      /*return this.http.get (this.url)
      .map (this.extractData)
      .catch (this.handleErrorObservable);
      */
      console.log ("Before using the get...");
      this.http.get(this.url).pipe(map(res => this.body = res.json()));
      return this.body;
 
    }
  
    private extractData (res: Response)
    {
      let body = res.json();
      return body;
    }

    private handleErrorObservable(error : Response|any)
    {
      console.error (error.message || error);
      return Observable.throw (error.message || error);
      
    }
}
