import { Component, OnInit } from '@angular/core';
import {InsuranceData} from '../InsuranceData';

@Component({
  selector: 'app-insurance',
  templateUrl: './insurance.component.html',
  styleUrls: ['./insurance.component.css']
})
export class InsuranceComponent implements OnInit {

  insuranceDataObj = new InsuranceData(123311, "Charan Kumar", 12321, "LIC Jeevan Anand");
  
  constructor() { }

  ngOnInit(): void {
  }

}
