import { Component, OnInit, Input, Output } from '@angular/core';
import { EventEmitter } from '@angular/core';



@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent {

  @Input() data : string[];
  @Output() messageToEmit =  new EventEmitter<string>();

 
  sendMessageToParent(message :string)
  {
    console.log ("message is about to send from child to parent..."+message);
    this.messageToEmit.emit(message);
  }
  }
  


