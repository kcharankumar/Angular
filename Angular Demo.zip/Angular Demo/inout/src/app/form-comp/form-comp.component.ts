import { Component, OnInit } from '@angular/core';
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, FormGroup} from '@angular/forms';
import { User } from '../user';

@Component({
  selector: 'app-form-comp',
  templateUrl: './form-comp.component.html',
  styleUrls: ['./form-comp.component.css']
})
export class FormCompComponent implements OnInit {

  firstName : string;

  user = new User("",0);
  

  constructor() { }

  ngOnInit(): void {
  }
 
  save (form1 : any, valid:boolean)
  {
    console.log (form1.name);
  }
  
  onSubmit(form1 : any, valid:boolean)
  {
    console.log ("Submit button is clicked...");
  }

  submitForm ()
  {
    alert (this.user.name +" is  "+ this.user.age +" years old");
    console.log (this.user.name +" is  "+ this.user.age +" years old");
  }

}
