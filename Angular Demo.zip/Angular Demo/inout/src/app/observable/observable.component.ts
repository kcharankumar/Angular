import { Component, OnInit } from '@angular/core';
import {Observable} from 'rxjs';

import {BookService} from '../book.service';
import {Book} from '../book';
import { ThrowStmt } from '@angular/compiler';




@Component({
  selector: 'app-observable', 
  templateUrl: './observable.component.html',
  styleUrls: ['./observable.component.css']
})
export class ObservableComponent implements OnInit {

  observableBooks : Observable <Book[]>
    book : Book[];
    errorMessage : string;
 
  constructor(private bookService : BookService) { }

  ngOnInit(): void {
    console.log ("Before reading the data from the http serivce..");
    this.observableBooks = this.bookService.getBooksWithObservable();
    console.log ("After reading the data from the http serivce..");
    this.observableBooks.subscribe(
      books => this.book = books,
      error => this.errorMessage =  <any>console.error);
  }

}