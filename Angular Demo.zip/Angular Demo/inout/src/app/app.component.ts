import { Component } from '@angular/core';
import {MyServiceService} from './my-service.service';
import {User} from "./user";


 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  fruits = ['Mango', 'Orange', 'Banana'];
  public randomNumber : number;
  receivedChildMessage : string;
  
   name1:string = "Charan";

  empid : number;
  name:string;
  dept: string;

  id:number=102;

   user = new User('Charan',24);

  constructor(){
    
  }

  
  addFruit (item:any)
  {
    console.log ("Before calling the service...");
    
  
   // this.myService.showTasks(); //Calling myService tasks...
    this.fruits.push (item);
  }

  getMessage (message :string)
  {
    alert ("Received message is : " + message);
    this.receivedChildMessage = message;
    console.log ("Received message is "+message);
  }

  save (val : any, valid : boolean)
  {
    console.log ("Form data : " + val)
  }

  submitForm ()
  {
    console.log (this.user.name +" is  "+ this.user.age +" years old");
  }

}
 