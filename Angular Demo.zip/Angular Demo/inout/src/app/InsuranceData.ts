export class InsuranceData
{
    policyNumber:number;
    name:string;
    amountPayable:number;
    policyName:string;
    
    constructor (policyNumber:number, name:string,amountPayable:number,policyName:string )
    {
       this.policyNumber = policyNumber;
       this.policyName = policyName;
       this.name = name;
       this.amountPayable = amountPayable;
    }

}