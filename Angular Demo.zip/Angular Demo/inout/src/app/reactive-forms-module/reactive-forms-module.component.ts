import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reactive-forms-module',
  templateUrl: './reactive-forms-module.component.html',
  styleUrls: ['./reactive-forms-module.component.css']
})
export class ReactiveFormsModuleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
