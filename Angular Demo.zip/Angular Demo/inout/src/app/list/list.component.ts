import { Component, OnInit } from '@angular/core';
import {Product_info} from '../Prouct_info';
import {Router, ActivatedRoute, Params} from "@angular/router";

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  title:string = 'Routing module';
     
  id : number;

    productList : Product_info[] = [
    { productId : 101, productName : 'Samsung TV', productCost : 25000},
    { productId : 102, productName : 'MI MObile', productCost : 25000},
    { productId : 103, productName : 'LG Washing machine..', productCost : 25000}
   
  ]
  constructor(private route:ActivatedRoute) { 
    route.params.subscribe (params => {this.id=params['id'];});
    
    alert ("Data is : " + this.id);
  }

  ngOnInit(): void {
    
    
    
  }

}
