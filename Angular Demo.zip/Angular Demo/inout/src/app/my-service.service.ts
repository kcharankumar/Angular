import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {

  constructor() { }

 //create HTTP Task
 createTask (data ):void
 {
   console.log ("Created a task...1");
 }

 showTasks ():void{
   console.log ("Here are the tasks in showTasks()...");
 }
}
